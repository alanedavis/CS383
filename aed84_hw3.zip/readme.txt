Homework 3 Submission

Folder layout / Contents:
1. aed84_hw3.m (file)
2. x06Simple.csv (file)

If your folder is organized how it is above it will run no problem.
